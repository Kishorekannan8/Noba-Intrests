# AMLoginSignup
Login/Signup ViewController for iOS.<br>
Write in Xcode8 and Swift3

Looking for Android version? Checkout repository created by [Irfan Raza](https://twitter.com/irfaan_aa) on Android Studio - [Single page signin and Signup](https://github.com/irfaan008/OnePageSigninSignup)

# Preview 

<img src="https://raw.githubusercontent.com/amirdew/AMLoginSignup/master/AMLS-preview.gif" width="320" height="580"><br>

## CREDITS
* Special Thanks to [Yaroslav Zubko](https://dribbble.com/Yar_Z) for design.
