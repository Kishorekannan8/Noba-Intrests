//
//  AppDelegate.h
//  kkk
//
//  Created by SravanthiKishore on 11/07/18.
//  Copyright © 2018 SravanthiKishore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

